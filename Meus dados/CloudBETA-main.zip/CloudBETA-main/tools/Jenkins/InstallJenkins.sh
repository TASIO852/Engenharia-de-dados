docker run -d --name jenkins -p 8989:8080 -p 50000:50000 jenkins_data:/var/jenkins_home jenkins/jenkins:lts-jdk11

#! Documentaçao
# https://github.com/jenkinsci/docker/blob/master/README.md
# https://www.youtube.com/watch?v=fodA9rM5xoo&t=71s