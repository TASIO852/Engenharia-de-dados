from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator

from datetime import datetime, timedelta

from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator

with DAG(
    'ETL Financas',
    default_args={
        'depends_on_past': False,
        'email': ['airflow@example.com'],
        'email_on_failure': False,
        'email_on_retry': False,
        'retries': 1,
        'retry_delay': timedelta(minutes=5),
    },
    description='A simple tutorial DAG',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2021, 1, 1),
    catchup=False,
    tags=['example'],
) as dag:
    init_kafka = BashOperator(
        task_id='topic_create',
        bash_command='/home/timedados/Documents/Cloud/tools/Kafka/InitKafka.sh',
    )

producer = PythonOperator(
    task_id='producer',
    python_callable='/home/timedados/Documents/Cloud/tools/Kafka/Producer/producer.py'
)

init_spark = BashOperator(
    task_id='init_spark',
    bash_command='/home/timedados/Documents/Cloud/tools/Spark/Init_spark.sh'
)

jdbc_to_spark_job = SparkJDBCOperator(
    cmd_type='jdbc_to_spark',
    jdbc_table="foo",
    spark_jars="${SPARK_HOME}/jars/postgresql-42.2.12.jar",
    jdbc_driver="org.postgresql.Driver",
    metastore_table="bar",
    save_mode="overwrite",
    save_format="JSON",
    task_id="jdbc_to_spark_job",
)

spark_to_jdbc_job = SparkJDBCOperator(
    cmd_type='spark_to_jdbc',
    jdbc_table="foo",
    spark_jars="${SPARK_HOME}/jars/postgresql-42.2.12.jar",
    jdbc_driver="org.postgresql.Driver",
    metastore_table="bar",
    save_mode="append",
    task_id="spark_to_jdbc_job",
)

batch_spark = PythonOperator(
    task_id='batch_spark',
    python_callable='/home/timedados/Documents/Cloud/tools/Spark/Spark batch/batch.py'
)

consumer_kafka = PythonOperator(
    task_id='consumer_kafka',
    python_callable='/home/timedados/Documents/Cloud/tools/Kafka/Consumer/consumer.py'
)

consumer_spark_sql = PythonOperator(
    task_id='consumer_spark_sql',
    python_callable='/home/timedados/Documents/Cloud/tools/Spark/Spark batch/Batch.py'
)
