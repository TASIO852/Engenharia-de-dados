docker run -it 5d00763e351c0e5bf79516ebb4ae9c371e2ffaf2763bcd64c4a3eb9422b697b1 \
spark-submit \
--packages "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0" \
--master "spark://spark-master:7077" \
--py-files ConsumerBatch.py

##############################!
docker exec -it 5d00763e351c0e5bf79516ebb4ae9c371e2ffaf2763bcd64c4a3eb9422b697b1 \
spark-submit \
--packages "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0" \
--master "spark://spark-master:7077" \
--py-files ConsumerBatch.py

##############################!
docker run -it 5d00763e351c0e5bf79516ebb4ae9c371e2ffaf2763bcd64c4a3eb9422b697b1 \
spark-submit \
--packages "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0" \
--master "spark://spark-master:7077" \
--conf spark.jars.ivy=/opt/bitnami/spark/ivy/org.apache.spark_spark-sql-kafka-0-10_2.12:3.2.0.jar \
--py-files ConsumerBatch.py

##############################!
docker exec -it 5d00763e351c0e5bf79516ebb4ae9c371e2ffaf2763bcd64c4a3eb9422b697b1 \
spark-submit \
--packages "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0" \
--master "spark://spark-master:7077" \
--conf spark.jars.ivy=/opt/bitnami/spark/ivy/org.apache.spark_spark-sql-kafka-0-10_2.12:3.2.0.jar \
--py-files ConsumerBatch.py

##############################!
spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0 ConsumerBatch.py
##############################!

docker exec -it 5d00763e351c0e5bf79516ebb4ae9c371e2ffaf2763bcd64c4a3eb9422b697b1 \
spark-submit \
--packages "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0" \
--master "spark://spark-master:7077" \
--py-files ConsumerBatch.py

##############################!
sudo chmod 777 jars && \
docker exec -it 5d00763e351c0e5bf79516ebb4ae9c371e2ffaf2763bcd64c4a3eb9422b697b1 \
spark-submit \
--packages "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0" \
--master "spark://spark-master:7077" \
--py-files ConsumerBatch.py

##############################!
sudo chmod 777 jars && \
docker exec -it 5d00763e351c0e5bf79516ebb4ae9c371e2ffaf2763bcd64c4a3eb9422b697b1 \
spark-submit \
--packages "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0" \
--master "spark://spark-master:7077" \
--conf spark.jars.ivy=/opt/bitnami/spark/ivy \
ivy/org.apache.spark_spark-sql-kafka-0-10_2.12:3.2.0.jar

##############################!
docker exec -it 5d00763e351c0e5bf79516ebb4ae9c371e2ffaf2763bcd64c4a3eb9422b697b1 \
spark-shell \
--packages "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0" \
--master "spark://spark-master:7077" \
--py-files ConsumerBatch.py

##############################!
docker exec -it 5d00763e351c0e5bf79516ebb4ae9c371e2ffaf2763bcd64c4a3eb9422b697b1 \
pyspark \
--packages "org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0"
--master "spark://spark-master:7077" \
--py-files ConsumerBatch.py

#? possibilidades
docker run -it 5d00763e351c0e5bf79516ebb4ae9c371e2ffaf2763bcd64c4a3eb9422b697b1 \
spark-submit \
  --master "spark://spark-master:7077" \
  --deploy-mode cluster \
  --driver-memory 12g \
  --executor-memory 12g \
  --executor-cores 2 \
  --py-files ConsumerBatch.py \
