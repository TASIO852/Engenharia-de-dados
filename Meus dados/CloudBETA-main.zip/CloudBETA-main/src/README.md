# Apenas arquivos de excel e arquivos fixos

SSH servidor >> timedados@209.145.52.136
Senha SSH servidor >> #L!pp@us2@18
