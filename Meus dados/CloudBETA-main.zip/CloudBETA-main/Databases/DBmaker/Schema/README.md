# Schema do banco de dados DBmaker

## Para mais informaçoes va ate ao readme principal la tem todas as tabelas bem definidas
