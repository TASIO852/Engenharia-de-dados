<img  width=800 height=200 src="../../Images/Dbmaker/img/logo.jpg" ></img>

# **Oque e ?**

DBMaker é um banco de dados relacional (RDBMS) orientado a oferecer aos ISVs e usuários corporativos, escalabilidade e performance em suas aplicações de negócios.

[Video Explicativo](https://www.youtube.com/watch?v=e7mi3iNYfCE)

# **Para que serve ?**

O DBMaker foi projetado desde o início para ser um produto de padrões abertos líder do setor. ODBC (Open Database Connectivity) é a interface padrão suportada pela maioria dos bancos de dados e o ODBC está no coração do DBMaker. Você pode vincular facilmente seus aplicativos ao DBMaker para proteger seu investimento original. Quando você vincula outros bancos de dados ao mecanismo de banco de dados do DBMaker por meio de uma interface ODBC, camadas de conversão ineficientes são desnecessárias. Como resultado, você desfruta de maior velocidade, desempenho e estabilidade.

# **Como instalar e funciona dentro do container ?**

- Para a ultilizaçao do dbmaker dentro do container docker enessesario seguir a documentaçao do docker hub

- Logo apos coloque ele na network com os container que ele vai fazer a conexao e e configure o kafka que vai ser quem vai puxar os dados

[Docker hub](https://hub.docker.com/r/dbmaker/bundle)
