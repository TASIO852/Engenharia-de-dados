#! iteratividade com o container
docker exec -it 3be614be0383f91dc618f090da75bb5367079d0fbcd4d170aebfb4652827cc23 mongosh
# Logs do banco de dados
docker logs mongo