# Bancos de dados do projeto

## **DBMaker**

DBMaker é um banco de dados relacional (RDBMS) orientado a oferecer aos ISVs e usuários corporativos, escalabilidade e performance em suas aplicações de negócios.

## **Mongodb**

O MongoDB é um banco de dados orientado a documentos que possui código aberto (open source) e foi projetado para armazenar uma grande escala de dados, além de permitir que se trabalhe de forma eficiente com grandes volumes.

## **PostgreSQL**

PostgreSQL é um sistema gerenciador de banco de dados objeto-relacional baseado no POSTGRES, Versão 4.2, desenvolvido na Universidade da Califórnia no Departamento de Ciências da Computação em Berkeley, o qual foi pioneiro em muitos conceitos que vieram a estar disponíveis em alguns bancos de dados comerciais mais
