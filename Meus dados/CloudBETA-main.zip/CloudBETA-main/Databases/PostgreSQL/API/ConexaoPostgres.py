import psycopg2 as pg

engine = pg.connect(
    "dbname='lippaus' user='postgres' host='192.168.0.7' port='5432' password='#L!pp@us2@18'")