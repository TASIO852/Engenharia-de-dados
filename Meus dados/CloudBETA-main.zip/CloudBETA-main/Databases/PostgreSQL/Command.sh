#! usar programa
docker exec -it 8920192aaca44a9ee410cf5a2a5810ad37414a7c29ebaa5cd82784ed5d1af215 psql -U postgres -W postgres