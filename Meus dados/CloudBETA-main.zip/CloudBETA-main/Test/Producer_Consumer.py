# !pip install kafka-python
# Requirement already satisfied: kafka-python in /opt/miniconda/lib/python3.9/site-packages (2.0.2)
from kafka import KafkaConsumer, KafkaProducer, KafkaAdminClient
from kafka.admin import NewTopic
client = KafkaAdminClient(bootstrap_servers=['127.0.0.1:9092'],
                          client_id='admin-client')
text.update({'headline': random_row_text[0]['headline']})
text.update({'article': random_row_text[0]['article']})
text.update({'audio': '../data/test_amharic.wav'})
topic_list = []
topic_list.append(
    NewTopic(name='spark-transformed-text',
             num_partitions=1,
             replication_factor=1)
)
client.create_topics(new_topics=topic_list, validate_only=False)


def json_serializer(data):
    return json.dumps(data).encode('utf-8')


def get_partition(key, all, available):
    return 0


producer = KafkaProducer(
    bootstrap_servers=['127.0.0.1:9092'],
    value_serializer=json_serializer,
    partitioner=get_partition
)
producer.send("spark-transformed-text", text)
# <kafka.producer.future.FutureRecordMetadata at 0x7f6e3f2151c0>
producer.flush()
consumer = KafkaConsumer(
    "spark-transformed-text",
    bootstrap_servers='127.0.0.1:9092',
    auto_offset_reset='earliest',
    group_id='consumer-group-a'
)
print('<<<<<<<<<<<<<starting consumer>>>>>>>>>>>>>')
for msg in consumer:
    print('Text = {}'.format(json.loads(msg.value)))
