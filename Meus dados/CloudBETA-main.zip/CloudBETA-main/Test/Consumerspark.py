# # Inscreva-se em 1 tópico, com cabeçalhos
#   df = spark \
#     .read \
#     .format("kafka") \
#     .option("kafka.bootstrap.servers", "localhost:9092") \
#     .option("subscribe", "quickstart") \
#     .option("includeHeaders", "true") \
#     .load()
#   df.selectExpr("CAST(python-message AS STRING)", "CAST(message AS STRING)", "headers")

# # Inscreva-se em vários tópicos
#   df = spark \
#     .read \
#     .format("kafka") \
#     .option("kafka.bootstrap.servers", "localhost:9092") \
#     .option("subscribe", "quickstart") \
#     .load()
#   df.selectExpr("CAST(python-message AS STRING)", "(message AS STRING)")

# # Assine um padrão
#   df = spark \
#     .read \
#     .format("kafka") \
#     .option("kafka.bootstrap.servers", "localhost:9092") \
#     .option("subscribePattern", "quickstart") \
#     .load()
#   df.selectExpr("CAST(python-message AS STRING)", "(message AS STRING)")