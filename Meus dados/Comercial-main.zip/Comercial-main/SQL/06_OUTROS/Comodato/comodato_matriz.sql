    SELECT
        '1' AS FILIAL,
        CAST(
            LEFT(CAST(CLI.VDCLICLI_VEN AS VARCHAR(3)), 2) || '0' AS INT
        ) AS codsup,
        CAST(CLI.VDCLICLI_VEN AS INT) AS codven,
        CAST(CLI.VDCLICLI_CODPASTA1 AS INT) AS codpas,
        LEFT(
            REPEAT(
                '0',
                8 - LENGTH(CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)))
            ) || CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)),
            4
        ) || '-' || RIGHT(
            REPEAT(
                '0',
                8 - LENGTH(CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)))
            ) || CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)),
            4
        ) AS clireg,
        CLI.VDCLICLI_SIGLA AS apecli,
        CLI.VDCLICLI_RAZAO50 AS nomcli,
        CLI.VDCLICLI_BAIENT AS BAIRRO,
        CLI.VDCLICLI_MUNENT AS CIDADE,
        CLI.VDCLICLI_ESTENT AS UF,
        CLI.VDCLICLI_FONE AS TELEFONE_1,
        CLI.VDCLICLI_FONE2 AS TELEFONE_2,
        CEV.VDCEVPEN_NRCCEV AS CONTRATO,
        PROD.VDPRDPRD_CODR AS REDUZIDO,
        PROD.VDPRDPRD_DESCR AS DESCRICAO,
        TO_DATE(CAST(CEV.VDCEVPEN_DTE AS VARCHAR(8)), 'YYYYMMDD') AS EMISSAO,
        TO_DATE(CAST(CEV.VDCEVPEN_DTV AS VARCHAR(8)), 'YYYYMMDD') AS VENCIME,
        CEV.VDCEVPEN_QTDPRD AS QTDE,
        RIGHT(CAST(CEV.VDCEVPEN_NPED AS VARCHAR(12)), 4) AS PEDIDO,
        RIGHT(CAST(CEV.VDCEVPEN_CROMA AS VARCHAR(11)), 3) AS ROM
    FROM
        DBCONTROL2016001.CEVPED01 CEV
        INNER JOIN DBCONTROL2016001.CADCLI01 CLI ON CAST(
            LEFT(
                REPEAT(
                    '0',
                    8 - LENGTH(CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)))
                ) || CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)),
                4
            ) AS INT
        ) = CLI.VDCLICLI_REGI
        AND CAST(
            RIGHT(
                REPEAT(
                    '0',
                    8 - LENGTH(CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)))
                ) || CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)),
                4
            ) AS INT
        ) = CLI.VDCLICLI_NUM
        INNER JOIN DBCONTROL2016001.CADPRD01 PROD ON CAST(
            LEFT(
                REPEAT(
                    '0',
                    6 - LENGTH(CAST(CEV.VDCEVPEN_PROD AS VARCHAR(6)))
                ) || CAST(CEV.VDCEVPEN_PROD AS VARCHAR(6)),
                3
            ) AS INT
        ) = PROD.VDPRDPRD_CFAM
        AND CAST(
            RIGHT(
                REPEAT(
                    '0',
                    6 - LENGTH(CAST(CEV.VDCEVPEN_PROD AS VARCHAR(6)))
                ) || CAST(CEV.VDCEVPEN_PROD AS VARCHAR(6)),
                3
            ) AS INT
        ) = PROD.VDPRDPRD_NRO
    ORDER BY
        TO_DATE(CAST(CEV.VDCEVPEN_DTE AS VARCHAR(8)), 'YYYYMMDD'),
        RIGHT(CAST(CEV.VDCEVPEN_NPED AS VARCHAR(12)), 4);