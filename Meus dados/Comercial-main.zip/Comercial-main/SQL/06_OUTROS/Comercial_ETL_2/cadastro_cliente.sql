SELECT
    LEFT(
        REPEAT(
            '0',
            8 - LENGTH(
                CAST(
                    CAST(
                        CAST(
                            CONCAT(
                                CONCAT(
                                    REPEAT(
                                        '0',
                                        4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                                    ),
                                    CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                                ),
                                CONCAT(
                                    REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                                    CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                                )
                            ) AS VARCHAR(10)
                        ) AS INT
                    ) AS VARCHAR(8)
                )
            )
        ) || CAST(
            CAST(
                CAST(
                    CONCAT(
                        CONCAT(
                            REPEAT(
                                '0',
                                4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                            ),
                            CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                        ),
                        CONCAT(
                            REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                            CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                        )
                    ) AS VARCHAR(10)
                ) AS INT
            ) AS VARCHAR(8)
        ),
        4
    ) || '-' || RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(
                CAST(
                    CAST(
                        CAST(
                            CONCAT(
                                CONCAT(
                                    REPEAT(
                                        '0',
                                        4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                                    ),
                                    CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                                ),
                                CONCAT(
                                    REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                                    CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                                )
                            ) AS VARCHAR(10)
                        ) AS INT
                    ) AS VARCHAR(8)
                )
            )
        ) || CAST(
            CAST(
                CAST(
                    CONCAT(
                        CONCAT(
                            REPEAT(
                                '0',
                                4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                            ),
                            CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                        ),
                        CONCAT(
                            REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                            CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                        )
                    ) AS VARCHAR(10)
                ) AS INT
            ) AS VARCHAR(8)
        ),
        4
    ) AS CODIGO,
    CASE
        WHEN SUBSTRING(
            CONCAT(
                REPEAT(
                    '0',
                    15 - LENGTH(CAST(C.VDCLICLI_CGC AS VARCHAR(15)))
                ),
                CAST(C.VDCLICLI_CGC AS VARCHAR(15))
            ),
            10,
            4
        ) = '0000' THEN CAST(
            CONCAT(
                SUBSTRING(
                    CONCAT(
                        REPEAT(
                            '0',
                            15 - LENGTH(CAST(C.VDCLICLI_CGC AS VARCHAR(15)))
                        ),
                        CAST(C.VDCLICLI_CGC AS VARCHAR(15))
                    ),
                    1,
                    9
                ),
                SUBSTRING(
                    CONCAT(
                        REPEAT(
                            '0',
                            15 - LENGTH(CAST(C.VDCLICLI_CGC AS VARCHAR(15)))
                        ),
                        CAST(C.VDCLICLI_CGC AS VARCHAR(15))
                    ),
                    14,
                    2
                )
            ) AS VARCHAR(15)
        )
        ELSE CAST(C.VDCLICLI_CGC AS VARCHAR(15))
    END DOCUM,
    CASE
        WHEN SUBSTRING(
            CONCAT(
                REPEAT(
                    '0',
                    15 - LENGTH(CAST(C.VDCLICLI_CGC AS VARCHAR(15)))
                ),
                CAST(C.VDCLICLI_CGC AS VARCHAR(15))
            ),
            10,
            4
        ) = '0000' THEN 'CPF'
        ELSE 'CNPJ'
    END TIPO,
    RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(VDCLICLI_DTINCL AS VARCHAR(8)))
        ) || CAST(VDCLICLI_DTINCL AS VARCHAR(8)),
        8
    ) AS INCLUSAO,
    C.VDCLICLI_SIGLA AS FANTASIA,
    C.VDCLICLI_RAZAO50 AS RAZAO,
    CAST(V.VDVENVEN_SUPVD AS INT) AS SUP,
    CAST(C.VDCLICLI_VEN AS INT) AS VEND,
    C.VDCLICLI_CODPASTA1 AS PASTA,
    C.VDCLICLI_SEQPASTA1 AS SEQ,
    C.VDCLICLI_CAT AS CANAL,
    CV.VDCLICAT_NOME AS 'DESCRICAO CANAL',
    CASE
        WHEN LEFT(C.VDCLICLI_CAT, 1) = 'C'
        OR LEFT(C.VDCLICLI_CAT, 1) = 'I' THEN 'ASI'
        ELSE 'FRIO'
    END AS MERC,
    RTRIM(
        CAST(
            C.VDCLICLI_ENDFAT_TIP || ' ' || RTRIM(C.VDCLICLI_ENDFAT) || ', ' || CAST(C.VDCLICLI_ENDFAT_NR AS VARCHAR(5)) AS VARCHAR(250)
        )
    ) AS ENDERECO,
    C.VDCLICLI_CODBAI AS CODBAI,
    C.VDCLICLI_BAIENT AS BAIRRO,
    C.VDCLICLI_MUNENT AS CIDADE,
    C.VDCLICLI_ESTENT AS UF,
    CAST(
        CASE
            WHEN C.VDCLICLI_MOTBLO = '' THEN '0'
            ELSE C.VDCLICLI_MOTBLO
        END AS INT
    ) AS BLOQ,
    CAST(C.VDCLICLI_TPCOBRA AS VARCHAR(2)) || '-' || CAST(C.VDCLICLI_CPG AS VARCHAR(2)) AS COND_PAG,
    CP.VDCADPAG_DESCR AS PRAZO,
    C.VDCLICLI_CREDITO AS CREDITO,
    C.VDCLICLI_FONE AS TELEFONE_1,
    C.VDCLICLI_FONE2 AS TELEFONE_2,
    C.VDCLICLI_CEL1 AS TELEFONE_3,
    C.VDCLICLI_CEL2 AS TELEFONE_4,
    C.VDCLICLI_FAX AS TELEFONE_5,
    C.VDCLICLI_CONTATO AS CONTATO,
    CAST(C.VDCLICLI_XEWCOO AS VARCHAR(10)) AS 'LATITUDE',
    CAST(C.VDCLICLI_YNSCOO AS VARCHAR(10)) AS 'LONGITUDE',
    VDCLICLI_CLASSE AS CLASSE,
    VDCLICLI_EMAIL AS EMAIL
FROM
    DBCONTROL2016001.CADCLI01 C
    INNER JOIN DBCONTROL2016001.CADVEN01 V ON C.VDCLICLI_VEN = V.VDVENVEN_SIGLA
    INNER JOIN DBCONTROL2016001.CCAT01 CV ON C.VDCLICLI_CAT = CV.VDCLICAT_COD
    INNER JOIN DBCONTROL2016001.CONDPG01 CP ON C.VDCLICLI_CPG = CP.VDCADPAG_COD
ORDER BY
    CODIGO