SELECT
    -- vendedor
    V.VDVENVEN_SIGLA as codven_lig,
    V.VDVENVEN_NOME as nomven_lig,
    V.VDVENVEN_CARGO as nomcar_lig,
    V.VDVENVEN_NIVEL as tipcar_lig,
    V.VDVENVEN_SUPVD as codsup_lig,
    -- supervisor
    S.VDVENVEN_NOME as nomsup_lig
FROM
    -- vendedor
    DBCONTROL2016001.CADVEN01 V -- supervisor
    left join DBCONTROL2016001.CADVEN01 S ON V.VDVENVEN_SUPVD = S.VDVENVEN_SIGLA