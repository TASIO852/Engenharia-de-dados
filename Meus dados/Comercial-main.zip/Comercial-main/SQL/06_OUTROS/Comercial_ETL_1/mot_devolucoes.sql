SELECT
    vdcaddev_descr as desmot,
    vdcaddev_cod as motdev
from
    DBCONTROL2016001.TBDEVOL