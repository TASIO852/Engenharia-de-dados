# **DESVIO**

WINDOW_AVG([RXCLI - AVG VOL/FAT ANTES] + [RXCLI - SUM TEND ATUAL]) - [RXCLI - AVG VOL/FAT]

# RXCLI AVG VOL/FAT ANTES
WINDOW_SUM(
    SUM(IF [MesAno] = MAKEDATE(YEAR(TODAY()), (MONTH(TODAY())-1),1) 
        THEN [vol / fat] ELSE 0 END)
)

# RXCLI - SUM TEND ATUAL
WINDOW_SUM(
    SUM(IF TRIM([Somente este mês?]) = "Sim" 
        THEN ([vol / fat] / [Dias trabalhados]) * [Dias Possiveis ]
ELSE 0 END))

# RX CLI AVG FAT VOLT
WINDOW_SUM(
    SUM(IF //[MesAno] = MAKEDATE(YEAR(TODAY()), (MONTH(TODAY())-1),1) OR
           [MesAno] = MAKEDATE(YEAR(TODAY()), (MONTH(TODAY())-2),1) OR //penultimo mês
           [MesAno] = MAKEDATE(YEAR(TODAY()), (MONTH(TODAY())-3),1) OR //antepenultimo
           [MesAno] = MAKEDATE(YEAR(TODAY()), (MONTH(TODAY())-4),1)  //o que vem antes do antes
        THEN [vol / fat] ELSE 0 END)
) / 3