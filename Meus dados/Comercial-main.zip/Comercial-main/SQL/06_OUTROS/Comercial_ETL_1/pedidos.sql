SELECT
    --cabecalho
    1 as codfil,
    C.VDPEDCPE_NPED as numped,
    C.VDPEDCPE_DTEMIPED as datemi,
    C.VDPEDCPE_TXFIN AS taxfin,
    C.VDPEDCPE_MOT AS codmot,
    VDPEDCPP_FL_ORIGEM AS ORIGEM,
    LEFT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)))
        ) || CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)),
        4
    ) || '-' || RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)))
        ) || CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)),
        4
    ) AS clireg,
    --item pedido
    CAST(
        RIGHT(CAST(I.VDPEDIPE_TBPRD AS VARCHAR(8)), 2) AS INT
    ) AS TABELA,
    I.VDPEDIPE_ITEM as seqite,
    I.VDPEDIPE_NUMFAT as numfat,
    I.VDPEDIPE_NATOP as natope,
    I.VDPEDIPE_TBPRD AS codtab,
    I.VDPEDIPE_OCOKD AS oco,
    I.VDPEDIPE_MOTTROCA AS motbon,
    I.VDPEDIPE_ITEM AS codpro,
    I.VDPEDIPE_CODR AS codred,
    I.VDPEDIPE_CFAM as codfam,
    I.VDPEDIPE_NRO AS codfam2,
    --variaveis para formula apos no etl
    coalesce(I.VDPEDIPE_QTDPRD, 0.00) as v_qtdprd,
    coalesce(I.VDPEDIPE_QTDRET, 0.00) as v_qtdret,
    coalesce(I.VDPEDIPE_QTDS, 0.0000) as v_qtds,
    coalesce(I.VDPEDIPE_QTDSR, 0.0000) as v_qtdsr,
    --coalesce((I.VDPEDIPE_PREPRDT - I.VDPEDIPE_PREPRDR), 0.00)  AS vlrliq,
    --coalesce((I.VDPEDIPE_PREPRDR), 0.00)  AS vlrdev
    CASE
        WHEN I.VDPEDIPE_OCOKD IN (2, 4) THEN 0
        ELSE (I.VDPEDIPE_PREPRDT - I.VDPEDIPE_PREPRDR)
    END AS vlrliq,
    CASE
        WHEN I.VDPEDIPE_OCOKD IN (2, 4) THEN 0
        ELSE (I.VDPEDIPE_PREPRDR)
    END AS vlrdev,
    C.VDPEDCPE_VEN as codven,
    C.VDPEDCPE_MOTDEV as motdev
FROM
    ---cabecalho pedido
    DBCONTROL2016001.PEDCP01 C -- iten pedido
    inner join DBCONTROL2016001.PEDIT01 I ON C.VDPEDCPE_NPED = I.VDPEDIPE_NIT
    LEFT JOIN DBCONTROL2016001.VDPEDCPP ON VDPEDCPE_NPED = VDPEDCPP_NPED
WHERE
    --LEFT(CAST(C.VDPEDCPE_DTEMIPED AS VARCHAR(8)), 08) >= '20180101'
    --  C.VDPEDCPE_DTEMIPED >= ${LAST_UPDATE_INT}
    C.VDPEDCPE_DTEMIPED >= 20210101 --CAST(VDPEDCPE_DTEMIPED as INT) >= CAST(VDPEDCPE_DTEMIPED as INT) - 1
    and C.VDPEDCPE_FL not in (6, 9)
    and C.VDPEDCPE_NPED <> 0
    and I.VDPEDIPE_OCOKD IN (1, 2, 4, 7, 9, 41, 42)
    and C.VDPEDCPE_DTEMIPED <> 20200400 --and C.VDPEDCPE_NPED = 202001020675--
    --and LEFT(CAST(C.VDPEDCPE_DTEMIPED AS VARCHAR(8)), 08) = '20201126'
UNION
ALL
SELECT
    --cabecalho
    2 as codfil,
    C.VDPEDCPE_NPED as numped,
    C.VDPEDCPE_DTEMIPED as datemi,
    C.VDPEDCPE_TXFIN AS taxfin,
    C.VDPEDCPE_MOT AS codmot,
    VDPEDCPP_FL_ORIGEM AS ORIGEM,
    LEFT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)))
        ) || CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)),
        4
    ) || '-' || RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)))
        ) || CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)),
        4
    ) AS clireg,
    --item pedido
    CAST(
        RIGHT(CAST(I.VDPEDIPE_TBPRD AS VARCHAR(8)), 2) AS INT
    ) AS TABELA,
    I.VDPEDIPE_ITEM as seqite,
    I.VDPEDIPE_NUMFAT as numfat,
    I.VDPEDIPE_NATOP as natope,
    I.VDPEDIPE_TBPRD AS codtab,
    I.VDPEDIPE_OCOKD AS oco,
    I.VDPEDIPE_MOTTROCA AS motbon,
    I.VDPEDIPE_ITEM AS codpro,
    I.VDPEDIPE_CODR AS codred,
    I.VDPEDIPE_CFAM as codfam,
    I.VDPEDIPE_NRO AS codfam2,
    --variaveis para formula apos no etl
    coalesce(I.VDPEDIPE_QTDPRD, 0.00) as v_qtdprd,
    coalesce(I.VDPEDIPE_QTDRET, 0.00) as v_qtdret,
    coalesce(I.VDPEDIPE_QTDS, 0.0000) as v_qtds,
    coalesce(I.VDPEDIPE_QTDSR, 0.0000) as v_qtdsr,
    --coalesce((I.VDPEDIPE_PREPRDT - I.VDPEDIPE_PREPRDR), 0.00)  AS vlrliq,
    --coalesce((I.VDPEDIPE_PREPRDR), 0.00)  AS vlrdev
    CASE
        WHEN I.VDPEDIPE_OCOKD IN (2, 4) THEN 0
        ELSE (I.VDPEDIPE_PREPRDT - I.VDPEDIPE_PREPRDR)
    END AS vlrliq,
    CASE
        WHEN I.VDPEDIPE_OCOKD IN (2, 4) THEN 0
        ELSE (I.VDPEDIPE_PREPRDR)
    END AS vlrdev,
    C.VDPEDCPE_VEN as codven,
    C.VDPEDCPE_MOTDEV as motdev
FROM
    ---cabecalho pedido
    DBCONTROL3601002.PEDCP02 C -- iten pedido
    inner join DBCONTROL3601002.PEDIT02 I ON C.VDPEDCPE_NPED = I.VDPEDIPE_NIT
    LEFT JOIN DBCONTROL3601002.VDPEDCPP ON VDPEDCPE_NPED = VDPEDCPP_NPED
WHERE
    --LEFT(CAST(C.VDPEDCPE_DTEMIPED AS VARCHAR(8)), 08) >= '20180101'
    -- C.VDPEDCPE_DTEMIPED >= ${LAST_UPDATE_INT} and
    C.VDPEDCPE_DTEMIPED >= 20210101 --CAST(VDPEDCPE_DTEMIPED as INT) >= CAST(VDPEDCPE_DTEMIPED as INT) - 1
    and C.VDPEDCPE_FL not in (6, 9)
    and C.VDPEDCPE_NPED <> 0
    and I.VDPEDIPE_OCOKD IN (1, 2, 4, 7, 9, 41, 42)
    and C.VDPEDCPE_DTEMIPED <> 20200400 --and C.VDPEDCPE_NPED = 202001020675
    --and LEFT(CAST(C.VDPEDCPE_DTEMIPED AS VARCHAR(8)), 06) = '202004'