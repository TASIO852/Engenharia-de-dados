SELECT
    -- vendedor
    V.VDVENVEN_SIGLA as codven,
    V.VDVENVEN_NOME as nomven,
    V.VDVENVEN_CARGO as nomcar,
    V.VDVENVEN_NIVEL as tipcar,
    V.VDVENVEN_SUPVD as codsup,
    -- supervisor
    S.VDVENVEN_NOME as nomsup
FROM
    -- vendedor
    DBCONTROL2016001.CADVEN01 V -- supervisor
    left join DBCONTROL2016001.CADVEN01 S ON V.VDVENVEN_SUPVD = S.VDVENVEN_SIGLA