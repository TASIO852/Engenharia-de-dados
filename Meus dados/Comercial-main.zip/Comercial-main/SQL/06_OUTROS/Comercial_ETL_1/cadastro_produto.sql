-- NOVO SQL CADPROD01  -- 
SELECT
    -- produtos
    P.VDPRDPRD_CODR as codred,
    P.VDPRDPRD_PRECOM as PVV,
    P.VDPRDPRD_DESCRI as despro,
    P.VDPRDPRD_LINHA as codlin,
    P.VDPRDPRD_QTDUN AS qtdemb,
    P.VDPRDPRD_MEDIDA1 fator,
    coalesce(P.VDPRDPRD_QTDUN, 0.0000) as v_qtdun,
    coalesce(P.VDPRDPRD_MEDIDA1, 0.0000) as v_medida1,
    P.VDPRDPRD_GRPPRD as codgru,
    -- grupo produtos
    (PROD.VDPRDPCR_DESC) AS despro2,
    (PROD.VDPRDPCR_MARCA) as nommar,
    --(PROD.VDPRDPCR_CATEG) as nomcat,
    CASE
        WHEN (PROD.VDPRDPCR_CATEG) = 'DESCARTAVEL' THEN 'OW'
        WHEN (PROD.VDPRDPCR_CATEG) = 'RETORNAVEL' THEN 'RGB'
        WHEN (PROD.VDPRDPCR_CATEG) = 'MAINSTREAM' THEN 'PMM'
        WHEN (PROD.VDPRDPCR_CATEG) = 'MATERIAL' THEN 'MPDV'
        ELSE (PROD.VDPRDPCR_CATEG)
    END AS nomcat,
    --CASE WHEN LEFT(ABE.CRMOVMOV_NDUPL,3) = 'PRV'  THEN 'PRV' ELSE 'EFE' END as tippre
    (PROD.VDPRDPCR_SEGMTO) as nomseg,
    (PROD.VDPRDPCR_EMB) as nomtam,
    (PROD.VDPRDPCR_TIPO) as tippro,
    (PROD.VDPRDPCR_LINHA) as linha,
    (PROD.VDPRDPCR_TIPO_REF) as tipativpro,
    (PROD.VDPRDPCR_TAM_REF) as tamativpro,
    (PROD.VDPRDPCR_CAT_MKP) as catmar,
    --rtrim(PROD.FORNECEDOR) as nomfab,
    (PROD.VDPRDPCR_PORTA_REF) as portativpro,
    --campos novos
    (PROD.VDPRDPCR_CODFAM) as codfam,
    --VDPRDPCR_CODR
    (PROD.VDPRDPCR_TIPO) as tipo,
    (PROD.VDPRDPCR_MARCA) as marca,
    (PROD.VDPRDPCR_CORINGA) as coringa,
    (PROD.VDPRDPCR_FDS) as fds,
    (PROD.VDPRDPCR_COB_ESP) as cobesp,
    (PROD.VDPRDPCR_EMB) as tamanho,
    (PROD.VDPRDPCR_FOB) as fob,
    (PROD.VDPRDPCR_CREDITO_ICMS) as credicms,
    (PROD.VDPRDPCR_FRETE) as frete,
    (PROD.VDPRDPCR_CARRETO) as carreto,
    (PROD.VDPRDPCR_CMV) as cmv,
    (PROD.VDPRDPCR_DEBITO_PIS_COFINS) as piscof,
    (PROD.VDPRDPCR_CATEG1) as categ1,
    (PROD.VDPRDPCR_CATEG2) as categ2,
    (PROD.VDPRDPCR_CATEG3) as categ3
FROM
    -- produto
    DBCONTROL2016001.CADPRD01 P -- grupo produto
    left join DBCONTROL2016001.VDPRDPCR PROD ON PROD.VDPRDPCR_CODR = P.VDPRDPRD_CODR
where
    PROD.VDPRDPCR_TIPO not in ('TABACO', 'OUTROS') --and P.VDPRDPRD_CODR =  900089