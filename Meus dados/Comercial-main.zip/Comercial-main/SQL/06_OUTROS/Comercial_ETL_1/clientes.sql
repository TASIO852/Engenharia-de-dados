SELECT
    -- cliente
    A.VDCLICLI_NUM as codcli,
    VDCLICLI_NOME_PROMOCAO AS nompromo,
    A.VDCLICLI_REGI as codreg,
    RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(A.VDCLICLI_REGI AS VARCHAR(8)))
        ) || CAST(A.VDCLICLI_REGI AS VARCHAR(8)),
        4
    ) || '-' || RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(A.VDCLICLI_NUM AS VARCHAR(8)))
        ) || CAST(A.VDCLICLI_NUM AS VARCHAR(8)),
        4
    ) AS clireg,
    RTRIM(
        CAST(
            VDCLICLI_ENDFAT_TIP || ' ' || RTRIM(VDCLICLI_ENDFAT) || ', ' || CAST(VDCLICLI_ENDFAT_NR AS VARCHAR(5)) AS VARCHAR(250)
        )
    ) AS ENDERECO,
    VDCLICLI_FONE AS TELEFONE_1,
    VDCLICLI_FONE2 AS TELEFONE_2,
    RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(VDCLICLI_DTINCL AS VARCHAR(8)))
        ) || CAST(VDCLICLI_DTINCL AS VARCHAR(8)),
        8
    ) AS INCLUSAO,
    A.VDCLICLI_VEN as codven_lig,
    A.VDCLICLI_CODPASTA1 as codpas,
    A.VDCLICLI_CGC as numcgc,
    rtrim(A.VDCLICLI_RAZAO50) AS nomcli,
    rtrim(A.VDCLICLI_SIGLA) AS apecli,
    A.VDCLICLI_BAIFAT AS baicli,
    A.VDCLICLI_MUNFAT AS cidcli,
    A.VDCLICLI_ESTFAT as sigufs,
    A.VDCLICLI_XEWCOO AS latitude,
    A.VDCLICLI_YNSCOO AS longitude,
    A.VDCLICLI_TPCOBRA as tipcob,
    A.VDCLICLI_CPG AS codcpg,
    A.VDCLICLI_CAT AS codcan,
    --cod.canal
    A.VDCLICLI_CODHOLDING AS codhol,
    --cod holdin
    A.VDCLICLI_CODBANDEIRA AS codban,
    --
    CASE
        WHEN SUBSTRING(
            CONCAT(
                REPEAT(
                    '0',
                    15 - LENGTH(CAST(A.VDCLICLI_CGC AS VARCHAR(15)))
                ),
                CAST(A.VDCLICLI_CGC AS VARCHAR(15))
            ),
            10,
            4
        ) = '0000' THEN 'CPF'
        ELSE 'CNPJ'
    END tipcli,
    --tipo cliente
    --CASE WHEN LEFT(A.VDCLICLI_CAT,1) = 'C' OR LEFT(A.VDCLICLI_CAT,1) = 'I' THEN 'ASI' ELSE 'FRIO' END AS grucan, -- grupo canal
    CASE
        WHEN LEFT(A.VDCLICLI_CAT, 1) = 'C' THEN 'ASI'
        WHEN LEFT(A.VDCLICLI_CAT, 1) = 'I' THEN 'ADEGA'
        ELSE 'FRIO'
    END AS grucan,
    VDCLICLI_MOTBLO AS motblo,
    -- tipo cliente
    CV.VDCLICAT_NOME AS nomcan,
    -- bandeira-holding
    BAN.VDCLIHOL_NOME as nomhol
FROM
    -- cliente
    DBCONTROL2016001.CADCLI01 A -- canal
    LEFT Join DBCONTROL2016001.CCAT01 CV ON A.VDCLICLI_CAT = CV.VDCLICAT_COD -- tabela de bandeira
    left join DBCONTROL2016001.VDCLHO01 BAN ON A.VDCLICLI_CODHOLDING = BAN.VDCLIHOL_CODHOL
    AND A.VDCLICLI_CODBANDEIRA = BAN.VDCLIHOL_CODBAN