SELECT
    LEFT(
        REPEAT(
            '0',
            8 - LENGTH(
                CAST(
                    CAST(
                        CAST(
                            CONCAT(
                                CONCAT(
                                    REPEAT(
                                        '0',
                                        4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                                    ),
                                    CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                                ),
                                CONCAT(
                                    REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                                    CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                                )
                            ) AS VARCHAR(10)
                        ) AS INT
                    ) AS VARCHAR(8)
                )
            )
        ) || CAST(
            CAST(
                CAST(
                    CONCAT(
                        CONCAT(
                            REPEAT(
                                '0',
                                4 - LENGTH(CAST (C.VDCLICLI_REGI AS VARCHAR(4)))
                            ),
                            CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                        ),
                        CONCAT(
                            REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                            CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                        )
                    ) AS VARCHAR(10)
                ) AS INT
            ) AS VARCHAR(8)
        ),
        4
    ) || '-' || RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(
                CAST(
                    CAST(
                        CAST(
                            CONCAT(
                                CONCAT(
                                    REPEAT(
                                        '0',
                                        4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                                    ),
                                    CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                                ),
                                CONCAT(
                                    REPEAT(
                                        '0',
                                        4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR (4)))
                                    ),
                                    CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                                )
                            ) AS VARCHAR(10)
                        ) AS INT
                    ) AS VARCHAR(8)
                )
            )
        ) || CAST(
            CAST(
                CAST(
                    CONCAT(
                        CONCAT(
                            REPEAT(
                                '0',
                                4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                            ),
                            CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                        ),
                        CONCAT(
                            REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                            CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                        )
                    ) AS VARCHAR(10)
                ) AS INT
            ) AS VARCHAR(8)
        ),
        4
    ) AS CODIGO,
    C.VDCLICLI_SIGLA AS FANTASIA,
    C.VDCLICLI_RAZAO50 AS RAZAO,
    CAST(V.VDVENVEN_SUPVD AS INT) AS SUP,
    CAST(C.VDCLICLI_VEN AS INT) AS VEND,
    C.VDCLICLI_CODPASTA1 AS PASTA,
    RTRIM(
        CAST(
            C.VDCLICLI_ENDFAT_TIP || ' ' || RTRIM(C.VDCLICLI_ENDFAT) || ', ' || CAST(C.VDCLICLI_ENDFAT_NR AS VARCHAR(5)) AS VARCHAR(250)
        )
    ) AS ENDERECO,
    C.VDCLICLI_BAIENT AS BAIRRO,
    C.VDCLICLI_MUNENT AS CIDADE,
    C.VDCLICLI_FONE AS TELEFONE_1,
    C.VDCLICLI_FONE2 AS TELEFONE_2
FROM
    DBCONTROL2016001.CADCLI01 C
    INNER JOIN DBCONTROL2016001.CADVEN01 V ON C.VDCLICLI_VEN = V.VDVENVEN_SIGLA
    INNER JOIN DBCONTROL2016001.CCAT01 CV ON C.VDCLICLI_CAT = CV.VDCLICAT_COD
    INNER JOIN DBCONTROL2016001.CONDPG01 CP ON C.VDCLICLI_CPG = CP.VDCADPAG_COD
WHERE
    C.VDCLICLI_CAT IN ('A3', 'A5')
    AND CAST(
        CASE
            WHEN C.VDCLICLI_MOTBLO = '' THEN '0'
            ELSE C.VDCLICLI_MOTBLO
        END AS INT
    ) = 0
ORDER BY
    CODIGO;