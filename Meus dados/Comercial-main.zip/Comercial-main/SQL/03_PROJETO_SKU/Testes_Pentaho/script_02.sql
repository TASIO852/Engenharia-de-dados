CREATE TABLE IF NOT EXISTS 'cliente_sku'(
    SKU_NUMBER VARCHAR(255) NOT NULL,
    COD_CLIENTE VARCHAR(255) NOT NULL,
    FILIAL VARCHAR(255) NOT NULL,
    N_PEDIDO VARCHAR(255) NOT NULL,
    Data VARCHAR(255) NOT NULL,
    Cliente VARCHAR(255) NOT NULL
)
INSERT INTO
    'cliente_sku' (SKU_NUMBER, COD_CLIENTE)
VALUES
    (
        '1',
        LEFT(
            REPEAT(
                '0',
                8 - LENGTH(CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)))
            ) || CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)),
            4
        ) || '-' || RIGHT(
            REPEAT(
                '0',
                8 - LENGTH(CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)))
            ) || CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)),
            4
        ) AS "Código Cliente" FROM DBCONTROL2016001.PEDCP01 C
    )