IF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 1 THEN '0' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 1
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 2 THEN '1' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 2
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 3 THEN '2' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 3
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 4 THEN '3' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 4
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 5 THEN '4' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 5
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 6 THEN '5' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 6
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 7 THEN '6'
ELSE '7 +'
END,
####
IF { FIXED [Clientes],
[Filial]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } < 1 THEN '0' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } >= 1
AND { FIXED [Clientes],
[Filial]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } < 2 THEN '1' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } >= 2
AND { FIXED [Clientes],
[Filial]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } < 3 THEN '2' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } >= 3
AND { FIXED [Clientes],
[Filial]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } < 4 THEN '3' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } >= 4
AND { FIXED [Clientes],
[Filial]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } < 5 THEN '4' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } >= 5
AND { FIXED [Clientes],
[Filial]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } < 6 THEN '5' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } >= 6
AND { FIXED [Clientes],
[Filial]: AVG(
    { INCLUDE [Clientes]: COUNTD([Produtos]) }
) } < 7 THEN '6'
ELSE '7 +'
END { INCLUDE [Clientes]: SKU } ##################
IF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 1 THEN '0' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 1
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 2 THEN '1' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 2
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 3 THEN '2' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 3
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 4 THEN '3' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 4
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 5 THEN '4' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 5
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 6 THEN '5' ELSEIF { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } >= 6
AND { FIXED [Clientes]: AVG(
    { INCLUDE [Clientes]: [SKU #1 -  POR CLIENTE] }
) } < 7 THEN '6'
ELSE '7 +'
END #########
IF { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } < 1 THEN '0' ELSEIF { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } >= 1
AND { FIXED [Clientes]: AVG(#
{ INCLUDE [Clientes]: [SKU_###_1] }) } < 2 THEN '1' ELSEIF { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } >= 2
AND { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } < 3 THEN '2' ELSEIF { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } >= 3
AND { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } < 4 THEN '3' ELSEIF { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } >= 4
AND { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } < 5 THEN '4' ELSEIF { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } >= 5
AND { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } < 6 THEN '5' ELSEIF { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } >= 6
AND { FIXED [Clientes]: AVG({ INCLUDE [Clientes]: [SKU_###_1] }) } < 7 THEN '6'
ELSE '7 +'
END