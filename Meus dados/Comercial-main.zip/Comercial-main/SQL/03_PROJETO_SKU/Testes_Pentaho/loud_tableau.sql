-- TESTE 1
CASE [botao] 
    WHEN 1 THEN [Sku Number]='1'
    WHEN 1 THEN [Sku Number]='2'
    WHEN 1 THEN [Sku Number]='3'
    WHEN 1 THEN [Sku Number]='4'
    WHEN 1 THEN [Sku Number]='5'
END

-- TESTE 2
CASE COUNTD(codpro)S 
    WHEN 1 THEN 'N 1'
    WHEN 2 THEN 'N 2'
    WHEN 3 THEN 'N 3'
    WHEN 4 THEN 'N 4'
END
S
IF [Clientes] THEN '1'
ELSEIF [Clientes] THEN '2'
ELSEIF [Clientes] THEN '3'
ELSEIF [Clientes] THEN '4'
ELSE 'OTHERS' END



