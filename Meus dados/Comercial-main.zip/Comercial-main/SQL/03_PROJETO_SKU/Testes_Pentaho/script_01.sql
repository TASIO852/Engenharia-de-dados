SELECT
    '1' as "Filial",
    C.VDPEDCPE_NPED as "Nº Pedido",
    C.VDPEDCPE_DTEMIPED as "Data",
    LEFT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)))
        ) || CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)),
        4
    ) || '-' || RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)))
        ) || CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)),
        4
    ) AS "Código Cliente",
FROM
    DBCONTROL2016001.PEDCP01 C
    INNER JOIN DBCONTROL2016001.PEDIT01 I ON C.VDPEDCPE_NPED = I.VDPEDIPE_NIT
    LEFT JOIN DBCONTROL2016001.VDPEDCPP ON VDPEDCPE_NPED = VDPEDCPP_NPED
GROUP BY
    LEFT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)))
        ) || CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)),
        4
    ) || '-' || RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)))
        ) || CAST(C.VDPEDCPE_CODCLI AS VARCHAR(8)),
        4
    ) AS 'Código'