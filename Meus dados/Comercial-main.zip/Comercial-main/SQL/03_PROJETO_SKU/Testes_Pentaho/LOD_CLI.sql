//IF TRIM([Somente este mês?]) = 'Sim' AND TRIM([Filtro - SKU]) = 'Sim' AND
    //TRIM([Tipo Produto]) = 'RGB' THEN [SKU RGB (1 - 4)] END

    CASE [Período [Mês Atual]]]
    WHEN 3 THEN
        IF 
            TRIM([SKU_PERIODO]) = 'MENSAL' AND
            TRIM([Filtro - SKU]) = 'Sim' 
        THEN [SKU_BOTOES_SKU] END
    WHEN 7 THEN
    IF 
            TRIM([SKU_PERIODO]) = 'TRIMESTRE' AND
        TRIM([Filtro - SKU]) = 'Sim' 
    THEN [SKU_BOTOES_SKU] END 
WHEN 5  THEN
   IF 
        TRIM([SKU_PERIODO]) = 'ANO_ATUAL' AND
        TRIM([Filtro - SKU]) = 'Sim' 
    THEN [SKU_BOTOES_SKU] END 
WHEN 6  THEN
   IF 
        TRIM([SKU_PERIODO]) = 'TUDO' AND
        TRIM([Filtro - SKU]) = 'Sim' 
    THEN [SKU_BOTOES_SKU] END
END


0 - TUDO
1 - ESTE MES
2 - ESTE TRIMESTRE
3 - ESTE ANO