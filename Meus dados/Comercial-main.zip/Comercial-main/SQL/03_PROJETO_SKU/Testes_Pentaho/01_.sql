CASE [Período [Ano Atual]]]
        WHEN 6 THEN 
        
        IF 
            NOT TRIM([Linha]) IN ("ATIVO", "ZNAO SE APLICA", "MATERIAL SUPORTE", "MATERIAL" ) AND 
            TRIM([Categoria]) = 'CERVEJA' AND
            TRIM([SKU_TIPO]) = 'CERV' AND  
            [Data] = [Data] AND
            TRIM([SKU_PERIODO]) = 'TUDO'
            THEN [SKU_BOTOES_SKU] 
        ELSEIF
            
            NOT TRIM([Linha]) IN ("ATIVO", "ZNAO SE APLICA", "MATERIAL SUPORTE", "MATERIAL" ) AND 
           
            TRIM([SKU_TIPO]) = 'TOTAL' AND  
            [Data] = [Data] AND
            TRIM([SKU_PERIODO]) = 'TUDO'
            THEN [SKU_BOTOES_SKU] 
        END
            WHEN 3 THEN 
        
        IF 
            NOT TRIM([Linha]) IN ("ATIVO", "ZNAO SE APLICA", "MATERIAL SUPORTE", "MATERIAL" ) AND 
            TRIM([Categoria]) = 'CERVEJA' AND
            TRIM([SKU_TIPO]) = 'CERV' AND  
            MONTH([Data]) = MONTH(TODAY()) AND  YEAR([Data]) = YEAR(TODAY()) AND
            TRIM([SKU_PERIODO]) = 'MENSAL'
            THEN [SKU_BOTOES_SKU] 
        ELSEIF
            
            NOT TRIM([Linha]) IN ("ATIVO", "ZNAO SE APLICA", "MATERIAL SUPORTE", "MATERIAL" ) AND 
           
            TRIM([SKU_TIPO]) = 'TOTAL' AND  
            MONTH([Data]) = MONTH(TODAY()) AND  YEAR([Data]) = YEAR(TODAY()) AND
            TRIM([SKU_PERIODO]) = 'MENSAL'
            THEN [SKU_BOTOES_SKU] 
        END
          WHEN 7 THEN 
        
        IF 
            NOT TRIM([Linha]) IN ("ATIVO", "ZNAO SE APLICA", "MATERIAL SUPORTE", "MATERIAL" ) AND 
            TRIM([Categoria]) = 'CERVEJA' AND
            TRIM([SKU_TIPO]) = 'CERV' AND  
            [3 LAST MONTH] AND
            TRIM([SKU_PERIODO]) = 'TRIMESTRE'
            THEN [SKU_BOTOES_SKU] 
        ELSEIF
            
            NOT TRIM([Linha]) IN ("ATIVO", "ZNAO SE APLICA", "MATERIAL SUPORTE", "MATERIAL" ) AND 
           
            TRIM([SKU_TIPO]) = 'TOTAL' AND  
            [3 LAST MONTH] and

            TRIM([SKU_PERIODO]) = 'TRIMESTRE'
            THEN [SKU_BOTOES_SKU] 
        END
     WHEN 5 THEN 
        
        IF 
            NOT TRIM([Linha]) IN ("ATIVO", "ZNAO SE APLICA", "MATERIAL SUPORTE", "MATERIAL" ) AND 
            TRIM([Categoria]) = 'CERVEJA' AND
            TRIM([SKU_TIPO]) = 'CERV' AND  
            YEAR([Data]) = YEAR(TODAY())  AND
            TRIM([SKU_PERIODO]) = 'ANO'
            THEN [SKU_BOTOES_SKU] 
        ELSEIF
            
            NOT TRIM([Linha]) IN ("ATIVO", "ZNAO SE APLICA", "MATERIAL SUPORTE", "MATERIAL" ) AND 
           
            TRIM([SKU_TIPO]) = 'TOTAL' AND  
            YEAR([Data]) = YEAR(TODAY())  AND
            TRIM([SKU_PERIODO]) = 'ANO'
            THEN [SKU_BOTOES_SKU] 
        END
END