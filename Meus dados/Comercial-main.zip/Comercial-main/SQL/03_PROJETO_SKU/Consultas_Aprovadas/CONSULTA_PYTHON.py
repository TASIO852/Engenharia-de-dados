import pyotp
totp = pyotp.TOTP("DTIYAKVSD27SFXAMDQORIPSGWQXYSE64")
print("Current OTP:", totp.now())