# **Projeto Clientes**
> ## Escópo do Projeto
Trata-se de um projeto para tratamento de dados e/ou informações relacionadas com os clientes da Lippaus Distribuição.

Essa é uma solulção em larga escala planejada para ser executada do período de 12/06/2022 em diante, visando a inclusão das informações de maneira já preparadas.

<details>
    <summary> Algumas informações </summary>
O andamento da produção de um arquivo SHP adequado depende de uma série de fatores relacionados com Geoprocessamento, sendo necessário um profissional adequado para gerar tal arquivo ou liberação de agentes públicos responsáveis por tais tarefas.
</details>

> ### #1 - Avisos

A utilização de arquivos em formato SHP não trouxeram resultados esperados, devido a uma série de ocorrências, entre elas, a desatualização do Shape File, que está em processo de atualização pelo Instituto Jones dos Santos Neves, os responsáveis por essa função no estado do Espírito Santo. 

No dia 08/08/2022, a responsável por tal função retornará de Férias.

> ### #2 - Processo de Transformação
Será necessário criar um projeto em larga escala para validar os endereço, bem como os dados cadastrais.

Pipeline do Processo:

    - Após a consulta, o arquivo passará por um processo de validação de informações, e quando ocorrer a inserção errada de alguma informação, deverá ser informado no e-mail do DBA, para que, tão logo, sejam providênciadas as alterações no Comercial
    
    - Essa Step precisa ocorrer no início do processo de extração, ou seja, quando a informação for buscada, passa por um processo de validação, caso a taxa de proximidade seja inferior a 80%, o DBA deve ser informado.

> ### #3 -  API REST

Será utilizando quase 100% dos Recursos Técnicos do Pentaho para recuperar todas as informações relacionadas com o endereço, para 
isso a API REST viaCorreios ou a do próprio Correios será utilizada, portanto, está é a solução para impedir que o problemade dados errados continue acontecendo. 

A solução poderá ser disponibilizada para outros usuários através do SWAGGER ou TOMCAT.
Oportunidade de implementação de novas soluções. 

> ### #4 - CUSTO



