SELECT
    LEFT(
        REPEAT(
            '0',
            8 - LENGTH(
                CAST(
                    CAST(
                        CAST(
                            CONCAT(
                                CONCAT(
                                    REPEAT(
                                        '0',
                                        4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                                    ),
                                    CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                                ),
                                CONCAT(
                                    REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                                    CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                                )
                            ) AS VARCHAR(10)
                        ) AS INT
                    ) AS VARCHAR(8)
                )
            )
        ) || CAST(
            CAST(
                CAST(
                    CONCAT(
                        CONCAT(
                            REPEAT(
                                '0',
                                4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                            ),
                            CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                        ),
                        CONCAT(
                            REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                            CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                        )
                    ) AS VARCHAR(10)
                ) AS INT
            ) AS VARCHAR(8)
        ),
        4
    ) || '-' || RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(
                CAST(
                    CAST(
                        CAST(
                            CONCAT(
                                CONCAT(
                                    REPEAT(
                                        '0',
                                        4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                                    ),
                                    CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                                ),
                                CONCAT(
                                    REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                                    CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                                )
                            ) AS VARCHAR(10)
                        ) AS INT
                    ) AS VARCHAR(8)
                )
            )
        ) || CAST(
            CAST(
                CAST(
                    CONCAT(
                        CONCAT(
                            REPEAT(
                                '0',
                                4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                            ),
                            CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                        ),
                        CONCAT(
                            REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                            CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                        )
                    ) AS VARCHAR(10)
                ) AS INT
            ) AS VARCHAR(8)
        ),
        4
    ) AS CODIGO,
    C.VDCLICLI_RAZAO50 AS RAZAO,
    CAST(C.VDCLICLI_VEN AS INT) AS VEND,
    C.VDCLICLI_CODPASTA1 AS PASTA,
    CASE
        WHEN C.VDCLICLI_DTINCL <> 0 THEN TO_DATE(
            REPEAT(
                '0',
                8 - LENGTH(CAST(C.VDCLICLI_DTINCL AS VARCHAR(8)))
            ) || CAST(C.VDCLICLI_DTINCL AS VARCHAR(8)),
            'DDMMYYYY'
        )
        ELSE NULL
    END INCLUSAO
FROM
    DBCONTROL2016001.CADCLI01 C
WHERE
    --C.VDCLICLI_VEN <= '153' OR C.VDCLICLI_VEN BETWEEN '301' AND '314'
    C.VDCLICLI_MOTBLO NOT IN ('1', '2', '3', '4', '5')
ORDER BY
    LEFT(
        REPEAT(
            '0',
            8 - LENGTH(
                CAST(
                    CAST(
                        CAST(
                            CONCAT(
                                CONCAT(
                                    REPEAT(
                                        '0',
                                        4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                                    ),
                                    CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                                ),
                                CONCAT(
                                    REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                                    CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                                )
                            ) AS VARCHAR(10)
                        ) AS INT
                    ) AS VARCHAR(8)
                )
            )
        ) || CAST(
            CAST(
                CAST(
                    CONCAT(
                        CONCAT(
                            REPEAT(
                                '0',
                                4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                            ),
                            CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                        ),
                        CONCAT(
                            REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                            CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                        )
                    ) AS VARCHAR(10)
                ) AS INT
            ) AS VARCHAR(8)
        ),
        4
    ) || '-' || RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(
                CAST(
                    CAST(
                        CAST(
                            CONCAT(
                                CONCAT(
                                    REPEAT(
                                        '0',
                                        4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                                    ),
                                    CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                                ),
                                CONCAT(
                                    REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                                    CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                                )
                            ) AS VARCHAR(10)
                        ) AS INT
                    ) AS VARCHAR(8)
                )
            )
        ) || CAST(
            CAST(
                CAST(
                    CONCAT(
                        CONCAT(
                            REPEAT(
                                '0',
                                4 - LENGTH(CAST(C.VDCLICLI_REGI AS VARCHAR(4)))
                            ),
                            CAST(C.VDCLICLI_REGI AS VARCHAR(4))
                        ),
                        CONCAT(
                            REPEAT('0', 4 - LENGTH(CAST(C.VDCLICLI_NUM AS VARCHAR(4)))),
                            CAST(C.VDCLICLI_NUM AS VARCHAR(4))
                        )
                    ) AS VARCHAR(10)
                ) AS INT
            ) AS VARCHAR(8)
        ),
        4
    )

--     IF 
--     LEN([Quinzenal]) = 3    
--     AND [Quinzenal] IN ("111") 
--     AND LEN(STR([Pasta])) != 2
--     AND CONTAINS([Quinzenal], STR([Pasta]))
-- THEN "ROTA OK" 
-- ELSE "ROTA FORA" END