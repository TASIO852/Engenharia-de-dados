SELECT DISTINCT TO_DATE(CAST(E.LFMENREL_DTE AS VARCHAR(8)), 'YYYYMMDD') AS 'ENTRADA',
                TO_DATE(REPEAT('0', 8-LENGTH(CAST(E.LFMENREL_DTC AS VARCHAR(8)))) || CAST(E.LFMENREL_DTC AS VARCHAR(8)), 'DDMMYYYY') AS 'EMISSAO',
                I.LFMENPFM_NF AS 'NOTA',
                CAST(I.LFMENPFM_CFISC AS VARCHAR(3)) || CAST(I.LFMENPFM_CFISC_D AS VARCHAR(1)) AS 'CFOP',
                I.LFMENPFM_CGCEMI9 AS 'CNPJ',
                LEFT(REPEAT('0', 6-LENGTH(CAST(I.LFMENPFM_PROD AS VARCHAR(6)))) || CAST(I.LFMENPFM_PROD AS VARCHAR(6)),3) || '-' || RIGHT(REPEAT('0', 6-LENGTH(CAST(I.LFMENPFM_PROD AS VARCHAR(6)))) || CAST(I.LFMENPFM_PROD AS VARCHAR(6)),3) AS FAMILIA,
                REPEAT('0', 7-LENGTH(CAST(I.LFMENPFM_CODPRDR AS VARCHAR(7)))) || CAST(I.LFMENPFM_CODPRDR AS VARCHAR(7)) AS REDUZIDO,
                P.VDPRDPRD_DESCR AS 'DESCRICAO',
                I.LFMENPFM_QTD AS 'CAIXA',
                I.LFMENPFM_PRECO AS 'PRECO',
                (P.VDPRDPRD_MEDIDA1*I.LFMENPFM_QTD) AS 'HL'
FROM DBCONTROL3601002.IT220205 I
INNER JOIN DBCONTROL3601002.LE220205 E ON I.LFMENPFM_NF = E.LFMENREL_NUMNF
AND I.LFMENPFM_SER = E.LFMENREL_SERNF
INNER JOIN DBCONTROL2016001.CADPRD01 P ON I.LFMENPFM_CODPRDR = P.VDPRDPRD_CODR
WHERE TO_DATE(REPEAT('0', 8-LENGTH(CAST(E.LFMENREL_DTC AS VARCHAR(8)))) || CAST(E.LFMENREL_DTC AS VARCHAR(8)), 'DDMMYYYY') >= '20220501'
    AND CAST(I.LFMENPFM_CFISC AS VARCHAR(3)) || CAST(I.LFMENPFM_CFISC_D AS VARCHAR(1)) IN ('1102',
                                                                                           '2102',
                                                                                           '1403',
                                                                                           '2403',
                                                                                           '1910',
                                                                                           '2910')