SELECT
    CAST(
        LEFT(CAST(CLI.VDCLICLI_VEN AS VARCHAR(3)), 2) || '0' AS INT
    ) AS codsup,
    CAST(CLI.VDCLICLI_VEN AS INT) AS codven,
    CAST(CLI.VDCLICLI_CODPASTA1 AS INT) AS codpas,
    LEFT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)))
        ) || CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)),
        4
    ) || '-' || RIGHT(
        REPEAT(
            '0',
            8 - LENGTH(CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)))
        ) || CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)),
        4
    ) AS clireg,
    CLI.VDCLICLI_SIGLA AS apecli,
    CLI.VDCLICLI_RAZAO50 AS nomcli,
    CEV.VDCEVPEN_NRCCEV AS CONTRATO,
    PROD.VDPRDPRD_CODR AS codred,
    PROD.VDPRDPRD_DESCR AS despro,
    CEV.VDCEVPEN_DTE AS datemi,
    CEV.VDCEVPEN_DTV AS datvct,
    CEV.VDCEVPEN_QTDPRD AS qtde,
    RIGHT(CAST(CEV.VDCEVPEN_NPED AS VARCHAR(12)), 4) AS numped,
    RIGHT(CAST(CEV.VDCEVPEN_CROMA AS VARCHAR(11)), 3) AS rom
FROM
    DBCONTROL2016001.CEVPED01 CEV
    INNER JOIN DBCONTROL2016001.CADCLI01 CLI ON CAST(
        LEFT(
            REPEAT(
                '0',
                8 - LENGTH(CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)))
            ) || CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)),
            4
        ) AS INT
    ) = CLI.VDCLICLI_REGI
    AND CAST(
        RIGHT(
            REPEAT(
                '0',
                8 - LENGTH(CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)))
            ) || CAST(CEV.VDCEVPEN_CODCLI AS VARCHAR(8)),
            4
        ) AS INT
    ) = CLI.VDCLICLI_NUM
    INNER JOIN DBCONTROL2016001.CADPRD01 PROD ON CAST(
        LEFT(
            REPEAT(
                '0',
                6 - LENGTH(CAST(CEV.VDCEVPEN_PROD AS VARCHAR(6)))
            ) || CAST(CEV.VDCEVPEN_PROD AS VARCHAR(6)),
            3
        ) AS INT
    ) = PROD.VDPRDPRD_CFAM
    AND CAST(
        RIGHT(
            REPEAT(
                '0',
                6 - LENGTH(CAST(CEV.VDCEVPEN_PROD AS VARCHAR(6)))
            ) || CAST(CEV.VDCEVPEN_PROD AS VARCHAR(6)),
            3
        ) AS INT
    ) = PROD.VDPRDPRD_NRO
WHERE
    CEV.VDCEVPEN_QTDPRD > 0