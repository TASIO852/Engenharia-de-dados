<center>

![IMAGE](/image/README/LOGO_LD.svg)

Esta é a descrição do Projeto do Comercial
> # ORIENTAÇÕES INICIAIS

</center>

Os projetos do Comercial possuem certa relevância no desenvolvimento do BI da Lippaus Distribuição, portanto, segue alguns do painéis responsáveis por algumas das principais alterações. 

- [ ] SKU
- [ ] CIDADES
- [ ] REDES
- [ ] ESPECIAIS
- [ ] VENDAS ATIVOS
- [ ] CHOPP
- [ ] HISTORICO MENSAL
- [ ] PERFORMANCE
- [ ] HISTORICO
- [ ] MENSAL


> # TESTANDO

- [ ] Testando os vínculos do painel de RGB
- [ ] Ajuste de dimensionamento do painel de Clientes;