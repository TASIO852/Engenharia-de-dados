<center>

![IMAGE](/image/README/LOGO_LD.svg)

Esta é a descrição do Painel Perfomance Time

> # PAINEL Perfomance Time 

</center>

## STEP `IAV`


Este indicador visa a construção de um sistema de avaliação de como funciona as visitas realizadas por vendedores nos clientes da LD, uma vez que as rotas de visitas que cada vendedor precisa realizar, os gerentes também necessitam realizar no mínimo 40 visitas as clientes para averiguar se determinados tipos de indicadores estãos endo cumpridos e/ou realizados de maneira adequada.

Um exemplo clássico é identificar o potencial do cliente, fato variável que depende exclusivamente de alguns motivos, entre os principais, a observação atenta da pessoa responsável pelo atendimento, seja ele o gerente ou o vendedor.

A LD possui algumas obrigações junto com a Fábrica HNK, em principal, é manter os clientes em potencial com cobertura extrema, enquanto clientes com potencial baixo, na maiorias das vezes, não recebe tanto destaque, uma vez que o investimento desnecessário de recursos em tal cliente pode gerar desperdicio.

⚠ NÃO DESPERDIÇAR TEMPO NO RECURSO, não significa que o cliente não é importante para a organização, pelo contrário, todo cliente deve ser valorizado e tratado com o máximo de respeito possível, sendo ele diamante ou premium. ⚠

Existem algumas aplicações que são utilizadas pelos funcionários da equipe de vendas.
O primeiro aplicativo é o "Palmer" da LD-HNK que visa estabelecer rotas de visitas para os vendedores de acordo com os clientes, sendo possível estabelecer uma linha de contato de algo grau de visita, conforme o preestabelecido entre a empresa e os clientes.

Ele está conectado diretamente com o Control, assim como o aplicativo "123".

## DADOS UTILIZADOS

*Em construção**


## STATUS

<center>

 **OCIOSO** 


<img style="text-align:center" src="../../image/Indicadores/humor_demal_apior.png" width="100" height="100">

 </center>
