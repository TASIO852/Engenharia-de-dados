<center>

![IMAGE](/Comercial/image/README/LOGO_LD.svg)

O projeto do SKU é um KPI desenvolvido com base na quantidade de produtos que estão sendo adquiridos pelos clientes.
> # ORIENTAÇÕES INICIAIS

</center>


<details> 
<summary> O que está sendo feito até agora?</summary>

O projeto de SKU tem como principal motivação acompanhar o andamento de SKU de maneira mensal, para resolver o problema de cálculo que não poderia ser realizado no tableau, está em desenvolvimento uma tablea
O projeto deo SKU tem como principal motivação acompanhar o andamento de SKU do painel que está em desenvolvimento pela Equipe de BI.
</details>
<center>

> # EXECUÇÃO DO ETL

![ETL](../../image/Pentaho/08_ETL_VSCODE.png)
</center>

- [ ] Inserir Novas Imagens no ETL do Projeto.


> # ETAPAS

- [x] Testar por Mês;
- [x] Testar por Trimestre;
- [x] Testar por Ano Atual;
- [x] Testar por Semanal;
- [x] Testar por Ano Anterior;
- [x] Testar por Todo Período;
- [x] Validar todas as alterações;
- [x] Inserir dos botões no Painel de OPP;
- [x] Validar INFO;
- [x] Reaplicar Filtros no Painel OPP;
- [x] Painel Especiais Concluído;
- [ ] Criação dos Campos Cálculados em Conjunto com os Parametros;
- [ ] Montar o ETL do Projeto SKU;
- [ ] Inserir botões no Painel SKU;
- [ ] Painel SKU - Aplicar Filtros de Somente Este Mês;
- [ ] Painel SKU - Correção do Gráfico de Barras SKU;
- [ ] Verificar Incompatabilidade do Painel;
- [ ] Checagem de Qualidade;

> # AJUSTES NA PROJETO
- [x] Padronização do Painel;
- [x] Ajuste do Paramentro Tipo ;
- [x] Ajuste do Parametro Período SKU;
- [x] Ajuste dos Botões de SKU;
- [ ] Integração do Paramentro no Painel de SKU e Teste de Qualidade;

> # INTEGRAÇÃO NO COMERCIAL 
- [x] Remoção dos Filtros de SKU;
- [x] Inserção dos Filtros Iniciais;
- [x] Análise de Impacto
- [ ] Limpeza de Tabelas Transicionais
- [ ] Aplicar filtros no Projeto de SKU
- [ ] Aplicar processos no Painel de Especiais
- [ ] CRIAÇÃO DE UM TERCEIRO PARAMENTRO DO PAINEL
- [ ] CERVEJA PRESELECIONADO
- [ ] 


> # INSTRUÇÕES
1. APLICAR LOD 'TIPO SKU'
2. APLICAR LOD 'PERÍODO SKU'
3. APLICA FILTRO (CONTAR SKU)