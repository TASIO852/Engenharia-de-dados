<center>

![IMAGE](/image/README/LOGO_LD.svg)

> # HISTÓRICO 
</center>
Este é um dos principais projetos desenvolvidos pela Equipe de Dados no Projeto do Comercial. Ele tem como objetivo representar os principais indicadores do projeto de maneira generalizada com objetivo principal no histórico de pedidos.


<details>
<summary> <strong> Filtros Utilizandos </strong> </summary>

- **Tipo de Vendedor**: trata-se de um parâmetro que tenta atualiza o vendedor `Cliente`[^1] e `Pedido`[^2].

- **Unidade**: trata-se de parâmetro que altera altera o volume entre unidade e hectolitragem, representadas pelas siglas `UN` e `HL`
- **Tipo Faturamento**: trata-se de parâmetro que altera entre o faturamento com adicional de fábrica e sem ele.
- **Período**: trata-se de um parâmetro para seleção da data de renderização do projeto.
- **Pasta**: trata-se da pasta de visita (rota) do vendedor
- **GV**: trata-se do gerente responsável pelo Vendedor ou pela mesa.
- **VD**: trata-se do vendedor responsável por determinado cliente e/ou pedido.
- **Clientes**: trata-se de filtro que relaciona todos os clientes com os seus respectivos códigos.
- **Redes**: trata-se de filtro que relaciona os clientes com as suas respectivas redes de venda.
- **CPF/CNPJ**: trata-se de filtro de pessoa física ou pesso jurídica.
- **Cidade** e **Bairro**: trata-se de filtros relacionados com o respectivo cliente.
- **Ocorrência**: ocorrências relacionadas com o Comercial.
- **Segmento**: segmentação de determinado produtos.
- **Canal**: canal de vendas
- **Grupo Canal**
- **Marca**
- **Produtos**
- **Embalagem**
- **Tipo Produto**
- **Linha**
- **Origem**
- **Matriz**

[^1]: Trata-se do vendedor vinculado com o Cliente, tal vendedor é responsável por visitar o cliente regularmente podendo ser ou não responsável por efetuar o pedido.
[^2]: Trata-se do vendedor pedido, responsável por efetuar o registro do pedido do cliente. 
</details>
