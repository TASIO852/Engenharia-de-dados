> # REUNIAO_2022_10_22

- Criação de Usuário Geral para reuniões com visualizações liberadas para todos os itens.

> # FALAS DE FÁBIO LIPPAUS
- Fala sobre um pouco do Tableau e melhor forma de utilizar a ferramenta do Painel, navegação de acordo
- Apresentação do Tableau,tem como bojetivo ser referencia em gestão e inovação para a HNK no longo do anos e dos períodos, 
- Todos os projetos é focado em inovação g estão para melhoria e crescimento da equipe



> # ALTERAÇÃO
  - Alterar o tipo de Identificador para o item;
  - Alterar para Grupo de Embalagem;
  - Remover até o dia atual da opção de período; - ok 
  - Reativar mundança do vendedor cliente e pedidos
  - Descrição Adicionar Motivo de Descrição. 
  - Atualizar as Descrições do Projeto 
  - Alterar parâmetros de filtragem por usuário, cada GV pode ver apenas informações sobre a sua mesa de filtragem conforme destacado por Fábio Lippaus.
  - Alterar os nomes do Motoristas.
  - Alterar os nomes dos Veículos.
  - Atualizar informações no Control.

  - Atrasos nas Rotas
  - Não existe a opção Outros
  - Motivo de Devolução existe nulo alterar, verificar quais são os outros motivos de devolução que estão sendo aplicadas no projeto do Painel Comercial. 
  - Nº Pedidos de tantos pedidos realizados, esses aqui foram devovlidos. 
  - Ajustar o Painel de Devolução, tornando-o mais importante.
  - Monitoras as mesas de atendimento.
  - Rever valores do Painel de Chopp
  - ATIVOS - COBERTOS E MÉDIA PARA O PAINEL DE CIDADES 
  - Matriz de Atendimento [ok]
  - Percentual no SKU Clientes (Fabio pediu)
  - Combo Acessível
        - Qual são os melhores SKU para cada tipo de cliente, como montar estratégias para melhorar os itens.
      - Número de PDV
      - 
