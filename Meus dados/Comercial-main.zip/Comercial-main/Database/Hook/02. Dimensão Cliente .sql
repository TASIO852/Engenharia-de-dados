SELECT
  "dim_cliente"."clireg" AS "clireg (dim_cliente)"
FROM "public"."dim_cliente" "dim_cliente"